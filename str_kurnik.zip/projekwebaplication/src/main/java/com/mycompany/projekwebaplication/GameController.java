package com.mycompany.projekwebaplication;


import java.util.Arrays;

import java.util.Random;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;



import javax.websocket.server.ServerEndpoint;



  
/**
     * Inicjalizuje cala gre
     */
@ServerEndpoint("/GameController")
public class GameController {
   
private static SharedData sharedData = new SharedData();
    private int[] diceValues;
    private final int[][] scores = new int[2][13];

   private int currentPlayer = 1;
    private final String[] categories = {
            "1", "2", "3", "4", "5", "6", "3x", "4x",
            "Full", "Mały Straight", "Duży Straight", "Generał", "Szansa", "TOTAL"
    };

    private boolean[] selectedDice;

    private boolean hasRolled = false;
    private boolean hasRerolled = false;
   

      @OnOpen
    public void onOpen(Session session) {
      
      
    SessionHandler.addSession(session); 
          //initializeGame(session);
    }

    @OnClose
    public void onClose(Session session) {
  SessionHandler.removeSession(session);
    }
    
     @OnMessage
    public void handleMessage(Session session, String message) {
        
         if(message.startsWith("start")){
            initializeGame(session);
         SessionHandler.broadcastMessage("tura"+currentPlayer);
         
         }
           if("end1".equals(message)){
   
      sharedData.wygrana(1);
         
         }
            if("end2".equals(message)){
   
        sharedData.wygrana(2);
         
         }
             if(message.startsWith("start")){
            initializeGame(session);
         SessionHandler.broadcastMessage("tura"+currentPlayer);
         
         }
         
 if ("1".equals(message)|| "2".equals(message)||"3".equals(message)||"4".equals(message)||"0".equals(message)) {
      int index = Integer.parseInt(message);
       selectedDice[index] = !selectedDice[index];
        }
 
 
 if(message.startsWith("przy1")){
     String resztaWiadomosci = message.substring("przy1".length());
     sharedData.Przypisz1(resztaWiadomosci);
     

     SessionHandler.broadcastMessage(sharedData.getgracz1());
 }
     if(message.startsWith("przy2")){
        
        String resztaWiadomosci = message.substring("przy2".length());
  sharedData.Przypisz2(resztaWiadomosci);

   
        SessionHandler.broadcastMessage(sharedData.getgracz2());

        }
 
 if ("roll".equals(message)){

rerollDice();
for (int i = 0; i < 5; i++) {
    
            sendResponse(session, i+"dice_"+diceValues[i]+".png");
}
 }
        
      if(message.startsWith("Points")){
          
            String resztaWiadomosci = message.substring("Points".length());

          int wyn = Integer.parseInt(resztaWiadomosci);

   // updateScore(initialScore+scoreIndex, currentPlayer);

  int newScore =checkConditionsForScore(wyn);
  wyn+=1;
          String mess = "index"+wyn;
 //  SessionHandler.broadcastMessage(message);
SessionHandler.broadcastMessage(mess);

// Convert the int to String before passing it to broadcastMessage
String mes = "Points"+String.valueOf(newScore);
    

// Call the broadcastMessage method with the String parameter
SessionHandler.broadcastMessage(mes);
endTurn(session);
   // updateScore( restOfMessage, currentPlayer)
      } 
 
    }

/**
     * Oblicza sume wartosci wszystkich kosci.
     * @return suma wszystkich wylosowanych kosci int
     */
    private int calculateSumOfAllDice() {
        int sum = 0;
        for (int die : diceValues) {
            sum += die;
        }
        return sum;
    }

/**
     * Oblicza sumę kosci o okreslonej wartosci.
     * @param okreslona wartosc kosci jako int
     * @return suma wszystkich okreslonych kosci int
     */
private int calculateSumOfSpecificValue(int value) {
        int sum = 0;
        for (int die : diceValues) {
            if (die == value) {
                sum += value;
            }
        }
        return sum;
    }

/**
     * Liczy wystąpienia każdej wartości kostki.
     * @return ilosc wystapien kosci jako int
     */
     private int[] countDiceValues() {
        int[] counts = new int[6];
        for (int die : diceValues) {
            counts[die - 1]++;
        }
        return counts;
    }
    
/**
     * Sprawdza warunki punktacji w zalesnosci od wybranej kategorii.
     * @param index w tabeli jako int
     * @return wynik do wpisania do tabeli jako int
     */
    private int checkConditionsForScore(int scoreIndex) {
        int[] counts = countDiceValues();
        int score = calculateScore(scoreIndex, counts);
        return score ;
    }

/**
     * Oblicza punkty dla konkretnej kategorii
     * @param wartosc indeksu tabeli int
     * @param tablica kosci
     */
    private int calculateScore(int scoreIndex, int[] counts) {
        if (scoreIndex == 6 && isThreeOfAKind(counts)) {
            return calculateSumOfAllDice();
        } else if (scoreIndex == 7) {
            return isFourOfAKind(counts) ? calculateSumOfAllDice() : 0;
        } else if (scoreIndex >= 0 && scoreIndex <= 5) {
            return hasSpecificValue(counts, scoreIndex + 1) ? calculateSumOfSpecificValue(scoreIndex + 1) : 0;
        } else if (scoreIndex == 8) {
            return isFullHouse() ? 25 : 0;
        } else if (scoreIndex == 9) {
            return isSmallStraight() ? 30 : 0;
        } else if (scoreIndex == 10) {
            return isLargeStraight() ? 40 : 0;
        } else if (scoreIndex == 11) {
            return isGeneral(counts) ? 50 : 0;
        } else if (scoreIndex == 12) {
            return calculateSumOfAllDice();
        }
        return 0;
    }

/**
     * Metody do sprawdzania, czy są spelnione okreslone warunki punktacji.
     * @param tablica kosci
     * @return true albo false
     */
    private boolean isThreeOfAKind(int[] counts) {
        for (int count : counts) {
            if (count >= 3) {
                return true;
            }
        }
        return false;
    }

/**
     * Metody do sprawdzania, czy są spelnione okreslone warunki punktacji.
     * @param tablica kosci
     * @return true albo false
     */
    private boolean isFourOfAKind(int[] counts) {
        for (int count : counts) {
            if (count >= 4) {
                return true;
            }
        }
        return false;
    }

/**
     * Metody do sprawdzania, czy są spelnione okreslone warunki punktacji.
     * @param tablica kosci
     * @return true albo false
     */
    private boolean isFullHouse() {
        boolean hasThreeOfAKind = false;
        boolean hasPair = false;

        for (int count : countDiceValues()) {
            if (count == 3) {
                hasThreeOfAKind = true;
            } else if (count == 2) {
                hasPair = true;
            }
        }

        return hasThreeOfAKind && hasPair;
    }

/**
     * Metody do sprawdzania, czy są spelnione okreslone warunki punktacji.
     * @param tablica kosci
     * @return true albo false
     */
    private boolean isGeneral(int[] counts) {
        for (int count : counts) {
            if (count >= 5) {
                return true;
            }
        }
        return false;
    }

/**
     * Metody do sprawdzania, czy są spelnione okreslone warunki punktacji.
     * @param tablica kosci
     * @return true albo false
     */
    private boolean isSmallStraight() {
        // Check for a small straight: 4 consecutive numbers
        int[] sortedDice = Arrays.copyOf(diceValues, diceValues.length);
        Arrays.sort(sortedDice);

        for (int i = 0; i <= 2; i++) {
            boolean isStraight = true;
            for (int j = i; j < i + 4; j++) {
                if (sortedDice[j] != sortedDice[j + 1] - 1) {
                    isStraight = false;
                    break;
                }
            }
            if (isStraight) {
                return true;
            }
        }

        return false;
    }

/**
     * Metody do sprawdzania, czy są spelnione okreslone warunki punktacji.
     * @param tablica kosci
     * @return true albo false
     */
    private boolean isLargeStraight() {
        // Check for a large straight: 5 consecutive numbers
        int[] sortedDice = Arrays.copyOf(diceValues, diceValues.length);
        Arrays.sort(sortedDice);

        for (int i = 0; i <= 1; i++) {
            boolean isStraight = true;
            for (int j = i; j < i + 5; j++) {
                if (sortedDice[j] != sortedDice[j + 1] - 1) {
                    isStraight = false;
                    break;
                }
            }
            if (isStraight) {
                return true;
            }
        }

        return false;
    }

/**
     * Sprawdza, czy istnieje przynajmniej jedna kostka o okreslonej wartosci.
     * @param tablica kosci
     * @param konkretna wartosc
     * @return true albo false
     */
    private boolean hasSpecificValue(int[] counts, int value) {
        return counts[value - 1] > 0;
    }

  

  

  

 
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
       private void initializeGame(Session session) {
      selectedDice = new boolean[5];

        diceValues = new int[5];
    
     
      playerRollDice();
 for (int i = 0; i < 5; i++) {
    
            sendResponse(session, i+"dice_"+diceValues[i]+".png");
}
 
    }
    
        private void sendResponse(Session session, String message) {
          SessionHandler.broadcastMessage(message);
    }

/**
     * Ponownie rzuca kosciami, ktore nie zostaly wybrane.
     */
  private void rerollDice() {
        if (!hasRerolled) {
            Random rand = new Random();
            for (int i = 0; i < 5; i++) {
                if (!selectedDice[i]) {
                    diceValues[i] = rand.nextInt(6) + 1;
                    
                }
            }
          
            hasRerolled = true;
           
        }
    }
       
/**
     * Rzuca kościami dla gracza.
     */
    private void playerRollDice() {
        Arrays.fill(selectedDice, false);

        Random rand = new Random();
        for (int i = 0; i < 5; i++) {
            if (!selectedDice[i]) {
                diceValues[i] = rand.nextInt(6) + 1;
            }
        }
    }

/**
     * Kończy aktualną ture, przelacza się na nastepnego gracza i rozpoczyna nową ture
     */
   private void endTurn(Session session) {
        currentPlayer = (currentPlayer == 1) ? 2 : 1;
       
          SessionHandler.broadcastMessage("tura"+currentPlayer);
        startNewTurn(session);
    }

/**
     * Resetuje flagi i rozpoczyna nową ture, rzucajac kosciami i wysyłajac odpowiedzi.
     */
    private void startNewTurn(Session session) {
        hasRolled = false;
        hasRerolled = false;
   
        Arrays.fill(selectedDice, false);
    
        playerRollDice();
        for (int i = 0; i < 5; i++) {
    
            sendResponse(session, i+"dice_"+diceValues[i]+".png");
}
        hasRolled = true;
    
    }
 
}