/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projekwebaplication;

import java.io.IOException;
import java.util.ArrayList;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;






/**
     * Reprezentuje talię kart w grze
     */
class Deck {
    private static List<Card> cards;

    public Deck() {
        cards = new ArrayList<>();
        String[] suits = {"kier", "karo", "trefl", "pik"};
        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"};

        for (String suit : suits) {
            for (String rank : ranks) {
                cards.add(new Card(suit, rank));
            }
        }

        // Shuffle the deck
        Collections.shuffle(cards);
    }

/**
     * Metoda zwracająca kartę z wierzchu talii (jeśli talia nie jest pusta).
     * @return karta z wierzchu talii
     */
    public static Card drawCard() {
        if (!cards.isEmpty()) {
            return cards.remove(0);
        } else {
            return null; // No cards left in the deck
        }
    }
}   
 
/**
     * Reprezentuje pojedynczą kartę w grze.
     */
 class Card {
    private final String suit;
    private final String rank;

    public Card(String suit, String rank) {
        this.suit = suit;
        this.rank = rank;
    }

/**
     * Metoda zwracająca reprezentację tekstową karty.
     * @return reprezentacja tekstowa karty
     */
    public String toString() {
        return rank + " of " + suit;
    }

/**
     * Metoda zwracająca wartość punktową karty.
     * @return wartosc punktowa karty
     */
    public int getValue() {
        switch (rank) {
            case "2":
                return 2;
            case "3":
                return 3;
            case "4":
                return 4;
            case "5":
                return 5;
            case "6":
                return 6;
            case "7":
                return 7;
            case "8":
                return 8;
            case "9":
                return 9;
            case "10":
            case "J":
            case "Q":
            case "K":
                return 10;
            case "A":
                return 11; // For simplicity, we'll treat Ace as 11 always
            default:
                return 2;
        }
    }

/**
     * Metoda zwracająca ścieżkę do ikony karty.
     * @return ściezka do ikony karty.
     */
    public String getImageIcon() {
        String folderName = suit.toLowerCase(); // Suit folder name (assuming lowercase suit names)
        String fileName = "karty/" + folderName + "/karta_" + suit + rank + ".png"; // Adjust the path based on your folder structure
        return fileName ;
    }

/**
     * Metoda zwracająca ścieżkę do ikony odwróconej karty.
     * @return sciezka do rewersu karty
     */
    public String getReversedImageIcon() {
        String fileName = "karty/karta_revers.png"; // Reversed card image
        return fileName;
    }

/**
     * Metoda zwracająca ścieżkę do ikony widocznej karty.
     * @return sciezka pliku grafiki karty
     */
    public String getVisibleImageIcon() {
        String folderName = suit.toLowerCase();
        String fileName = "karty/" + folderName + "/karta_" + suit + rank + ".png";
        return fileName;
    }
}

/**
     * Reprezentuje rękę gracza (zarówno gracza jak i krupiera)
     */
class Hand {
    private final List<Card> cards;

    public Hand() {
        cards = new ArrayList<>();
    }

/**
     * Metoda dodająca kartę do ręki.
     */
    public void addCard(Card card) {
        cards.add(card);
    }

/**
     * Metoda zwracająca niemodyfikowalną listę kart w ręce.
     */
    public List<Card> getCards() {
        return Collections.unmodifiableList(cards);
    }

/**
     * Metoda obliczająca i zwracająca sumaryczną wartość punktową kart w ręce, uwzględniając elastyczność Asów.
     */
    public int getScore() {
        int score = 0;
        int numAces = 0;

        for (Card card : cards) {
            score += card.getValue();
            if (card.getValue() == 11) { // Ace
                numAces++;
            }
        }

        // Adjust the score for Aces
        while (score > 21 && numAces > 0) {
            score -= 10;
            numAces--;
        }

        return score;
    }
}

/**
     * Główna klasa obsługująca logikę gry.
     */
@ServerEndpoint("/blackcontrol")
public class blackcontrol {
 private Deck deck;
    private int totalScore = 0;
    private int visibleScore = 0;
    private Hand playerHand;
    private Hand dealerHand;
    private boolean gameOver = false;
private String nick;
    private static final String JDBC_URL = "jdbc:derby://localhost:1527/test";
    private static final String USERNAME = "dawid";
    private static final String PASSWORD = "dawid";
    private static final String gra = "kosci";

    public blackcontrol() {
        // Constructor
        deck = new Deck();
        playerHand = new Hand();
        dealerHand = new Hand();
    }
    
/**
     * Metoda wywoływana przy otwarciu sesji, inicjująca grę.
     */
        @OnOpen
    public void onOpen(Session session) {

        initializeGame(session);
    }

/**
     * Metoda wywoływana przy zamknięciu sesji.
     */
    @OnClose
    public void onClose(Session session) {
     
    }

    /**
     * Metoda zakończająca grę i rozpoczynająca nową.
     */
    private void endGamenowe(Session session) {
    sendResponse(session, "d3" );
       sendResponse(session, "d4" );
       sendResponse(session, "d5" );
       sendResponse(session, "p3" );
       sendResponse(session, "p4" );
       sendResponse(session, "p5" );
       initializeGame(session);
    }
    
        public void wygrana() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            // Sprawdź, czy nick już istnieje w tabeli
           
            String selectQuery = "SELECT * FROM wynik WHERE nick = ?";
            try (PreparedStatement selectStatement = connection.prepareStatement(selectQuery)) {
                selectStatement.setString(1, nick);
                try (ResultSet resultSet = selectStatement.executeQuery()) {
                    if (resultSet.next()) {
                        // Nick już istnieje, zaktualizuj wynik
                        int currentResult = resultSet.getInt("wynik");
                        int newResult = currentResult + 1;

                        String updateQuery = "UPDATE wynik SET wynik = ? WHERE nick = ?";
                        try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                            updateStatement.setInt(1, newResult);
                            updateStatement.setString(2, nick);
                            updateStatement.executeUpdate();
                        }
                    } else {
                        // Nick nie istnieje, dodaj nowy rekord
                        String insertQuery = "INSERT INTO wynik (jakagra,nick, wynik) VALUES ('blackjack',?, 1)";
                        try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
                            insertStatement.setString(1, nick);
                            insertStatement.executeUpdate();
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    

    
    /**
     * Metoda sprawdzająca warunki zakończenia gry i ogłaszająca wynik.
     */
     private void endGame(Session session) {
        // Logika zakończenia gry i ogłoszenie wyniku
        if (playerHand.getScore() > 21) {
         sendResponse(session, "lose" );
      endGamenowe(session);
        } else if (dealerHand.getScore() > 21 || playerHand.getScore() > dealerHand.getScore()) {
             sendResponse(session, "Player wins!" );
             wygrana();
             
  
          endGamenowe(session);
        } else if (playerHand.getScore() < dealerHand.getScore()) {
                 sendResponse(session, "Dealer wins!" );
  endGamenowe(session);
        } 



    }
    
    /**
     * Metoda obsługująca wiadomości od klienta (np. "Hit1", "Hit2", "Stand") i podejmująca odpowiednie akcje w grze
     * @param string wiadomosc.
     */
    @OnMessage
    public void handleMessage(Session session, String message) {
            if(message.startsWith("nick")){
              nick =   message.substring(4);
             
            
            }
             
        if ("Hit1".equals(message) ) {
        
    Card drawnCard = deck.drawCard();
     if (drawnCard != null) {
        String cardIcon = drawnCard.getImageIcon();
             playerHand.addCard(drawnCard);
        sendResponse(session, "p3" + cardIcon);
        if (playerHand.getScore() > 21){
       endGame(session);}
    } else {
        // Handle the case when there are no cards left in the deck
        sendResponse(session, "No cards left in the deck.");
    }

        }
        if ("Hit2".equals(message) ) {
       
    Card drawnCard = deck.drawCard();
     if (drawnCard != null) {
        String cardIcon = drawnCard.getImageIcon();
             playerHand.addCard(drawnCard);
        sendResponse(session, "p4" + cardIcon);
        if (playerHand.getScore() > 21){
               endGame(session);}
    } else {
        // Handle the case when there are no cards left in the deck
        sendResponse(session, "No cards left in the deck.");
    }

        }
        
          if ("Hit3".equals(message) ) {
      
    Card drawnCard = deck.drawCard();
     if (drawnCard != null) {
        String cardIcon = drawnCard.getImageIcon();
             playerHand.addCard(drawnCard);
        sendResponse(session, "p5" + cardIcon);
        if (playerHand.getScore() > 21){
               endGame(session);}
    } else {
        // Handle the case when there are no cards left in the deck
        sendResponse(session, "No cards left in the deck.");
    }
     

        }
          if ("Hit4".equals(message) ) {
      
    Card drawnCard = deck.drawCard();
     if (drawnCard != null) {
        String cardIcon = drawnCard.getImageIcon();
             playerHand.addCard(drawnCard);
        sendResponse(session, "p6" + cardIcon);
        if (playerHand.getScore() > 21){
               endGame(session);}
    } else {
        // Handle the case when there are no cards left in the deck
        sendResponse(session, "No cards left in the deck.");
    }
     

        }
          
          if ("Stand".equals(message) ) {
              gameOver = true;
          endGame(session);
          
          }
    }

/**
     * Metoda inicjująca nową grę, rozdając karty początkowe.
     */
    private void initializeGame(Session session) {
        
gameOver = false;
        
       
    
     
  // Create an instance of Deck
    Card drawnCard = deck.drawCard();
     if (drawnCard != null) {
        String cardIcon = drawnCard.getImageIcon();
         dealerHand.addCard(drawnCard);
        sendResponse(session, "d1" + cardIcon);
    } else {
        // Handle the case when there are no cards left in the deck
        sendResponse(session, "No cards left in the deck.");
    }
 Card drawnCard2 = deck.drawCard();
  if (drawnCard2 != null) {
        String cardIcon = drawnCard2.getReversedImageIcon();
           dealerHand.addCard(drawnCard2);
        sendResponse(session, "d2" + cardIcon);
    } else {
        // Handle the case when there are no cards left in the deck
        sendResponse(session, "No cards left in the deck.");
    }
  Card drawnCard3 = deck.drawCard();
   if (drawnCard3 != null) {
        String cardIcon = drawnCard3.getImageIcon();
              playerHand.addCard(drawnCard3);
        sendResponse(session, "p1" + cardIcon);
    } else {
        // Handle the case when there are no cards left in the deck
        sendResponse(session, "No cards left in the deck.");
    }
   Card drawnCard4 = deck.drawCard();
    if (drawnCard4 != null) {
        String cardIcon = drawnCard4.getImageIcon();
            playerHand.addCard(drawnCard4);
        sendResponse(session, "p2" + cardIcon);
    } else {
        // Handle the case when there are no cards left in the deck
        sendResponse(session, "No cards left in the deck.");
    }
   
}
    
/**
     * Metoda wysyłająca odpowiedź do klienta przez sesję WebSocket.
     * @param string wiadomosc
     */
     private void sendResponse(Session session, String message) {
        try {
            session.getBasicRemote().sendText(message);
   
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

   
     
}