package com.mycompany.projekwebaplication;

import java.io.IOException;
import java.util.ArrayList;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Jest to klasa reprezentujaca endpoint WebSocket dla gry.
 */
@ServerEndpoint("/graWebSocket")
public class GraWebSocket {
    private static final String JDBC_URL = "jdbc:derby://localhost:1527/test";
    private static final String USERNAME = "dawid";
    private static final String PASSWORD = "dawid";
    private static final String gra = "wieksze";
    private String nickk = "tak";
    private static int Count = 0;
    private static int Rekord = 0;
    private int previousCardIndex =0;
    private String[] cards = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14"};
    private String[] suits = {"karo", "kier", "pik", "trefl"};
    private String[] deck;
 private int nextCardIndex = 1;
private int ilosckart = 51;
     /**
     * Metoda wywolywana przy nawiazaniu polaczenia WebSocket. Inicjalizuje talie kart, uruchamia gre i wysyla komunikaty do klienta.
     * @param parametr Opis parametru.
     */
    @OnOpen
    public void onOpen(Session session) {
        createAndShuffleDeck();
        initializeGame(session);
    }

/**
     * Metoda wywoływana przy zamknięciu połączenia WebSocket. Zapisuje lub aktualizuje wynik gracza w bazie danych.
     */
    @OnClose
    public void onClose(Session session) {
        saveOrUpdateResult(nickk);
    }

/**
     * Metoda wywoływana przy otrzymaniu wiadomości od klienta. W zależności od treści wiadomości, obsługuje zgadywanie, aktualizuje kartę lub ustawia nazwę gracza.
     */
    @OnMessage
    public void handleMessage(Session session, String message) {
        if ("Higher".equals(message) || "Lower".equals(message)) {
            handleGuess(session, message);
            Rekord = rekord(nickk);
            String rekord = String.valueOf("Twoj Rekord: " + Rekord);
            sendResponse(session, rekord);
            
        } else if ("UpdateCard".equals(message)) {
            updateCard(session);
        } else {
            nickk = message;
            Rekord = rekord(nickk);
            String rekord = String.valueOf("Twoj Rekord: " + Rekord);
            sendResponse(session, rekord);
            
                    
        }
    }

/**
     * Inicjalizuje gre dla danego gracza, ustawia ilosc kart w talii i aktualizuje karte.
     */
    private void initializeGame(Session session) {
     
        Count = 0;
         String deckcount = String.valueOf("Pozostała ilość kart w tali: " + ilosckart);
            sendResponse(session, deckcount);
        updateCard(session);
    }

/**
     * Pobiera najlepszy wynik (rekord) gracza z bazy danych.
     * @param nick- string z nazwa gracza.
     * @return rekord-rekord gracza
     */
    public static int rekord(String nick) {
        int rekord = 0;

        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            String query = "SELECT wynik FROM wynik WHERE nick = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, nick);

                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    rekord = resultSet.getInt("wynik");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return rekord;
    }

/**
     * Obsluguje zgadywanie, porownuje wartosc aktualnej karty z poprzednia i aktualizuje liczbe poprawnych zgadniec.
     * @param quess- nazwa zgadnietej karty jako string.
     */
  private void handleGuess(Session session, String guess) {
    
    int drawnCardValue = getCardValue(deck[nextCardIndex]);
    int previousCardValue = getCardValue(deck[previousCardIndex]);

    if (("Higher".equals(guess) && drawnCardValue > previousCardValue) ||
            ("Lower".equals(guess) && drawnCardValue < previousCardValue)) {
        Count++;
        
        --ilosckart;
        String deckcount = String.valueOf("Pozostała ilość kart w tali: " + ilosckart);
            sendResponse(session, deckcount);
    } else {
        if (drawnCardValue == previousCardValue) {
            sendResponse(session, "Masz farta bo trafiasz ta sama karte:" + deck[nextCardIndex]);
            String deckcount = String.valueOf("Pozostała ilość kart w tali: " + ilosckart);
            sendResponse(session, deckcount);
        } else {
            sendResponse(session, "Incorrect. Drawn card: " + deck[nextCardIndex]+ deck[previousCardIndex]);
            saveOrUpdateResult(nickk);
            Rekord = rekord(nickk);
            Count = 0;
            ilosckart=51;
            createAndShuffleDeck();
             String deckcount = String.valueOf("Pozostała ilość kart w tali: " + ilosckart);
            sendResponse(session, deckcount);
        }
    }

    previousCardIndex = nextCardIndex;
     nextCardIndex++;
    updateCard(session);
}

/**
     * Pobiera wartosc liczbowa karty na podstawie jej nazwy.
     * @param card- nazwa karty jako string
     * @return wartosc karty jako int
     */
private int getCardValue(String card) {
    // Pobierz wartość karty na podstawie jej nazwy
    String valueString = card.substring(0);
    valueString = card.replaceAll("[^0-9]", ""); // Usuń wszystkie znaki niebędące cyframi
    try {
        return Integer.parseInt(valueString);
    } catch (NumberFormatException e) {
        return 0; // Domyślnie, jeśli wartość karty jest nieznana
    }
}

/**
     * Zapisuje lub aktualizuje wynik gracza w bazie danych w zaleznosci od tego, czy gracz już istnieje.
     * @param nick gracza jako string
     */
    public static void saveOrUpdateResult(String nick) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            String checkIfExistsQuery = "SELECT * FROM wynik WHERE nick = ?";
            try (PreparedStatement checkIfExistsStmt = connection.prepareStatement(checkIfExistsQuery)) {
                checkIfExistsStmt.setString(1, nick);
                ResultSet resultSet = checkIfExistsStmt.executeQuery();

                if (resultSet.next()) {
                    String jakagra = resultSet.getString("jakagra");
                    int existingScore = resultSet.getInt("wynik");
                    if (Count > existingScore) {
                        String updateQuery = "UPDATE wynik SET wynik = ? WHERE nick = ?";
                        try (PreparedStatement updateStmt = connection.prepareStatement(updateQuery)) {
                            updateStmt.setInt(1, Count);
                            updateStmt.setString(2, nick);
                            updateStmt.executeUpdate();
                        }
                    }
                } else {
                    String insertQuery = "INSERT INTO wynik (nick, jakagra,wynik) VALUES (?, ?, ?)";
                    try (PreparedStatement insertStmt = connection.prepareStatement(insertQuery)) {
                        insertStmt.setString(1, nick);
                        insertStmt.setString(2, gra);
                        insertStmt.setInt(3, Count);
                        insertStmt.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

/**
     * Tworzy talie kart, tasuje je i przypisuje do zmiennej "deck".
     */
    private void createAndShuffleDeck() {
        List<String> deckList = new ArrayList<>();
        for (String suit : suits) {
            for (String card : cards) {
                deckList.add(suit + card);
            }
        }

        Collections.shuffle(deckList, new Random());
        deck = deckList.toArray(new String[0]);
    }

/**
     * Aktualizuje kartę wysyłając informację o kolejnej karcie do klienta.
     */
    private void updateCard(Session session) {
    if (deck.length == 0 || previousCardIndex >= deck.length) {
        sendResponse(session, "Koniec gry. Gratulacje!");
        return;
    }

    String drawnCard = deck[previousCardIndex];


    sendResponse(session, "karty/karta_" + drawnCard + ".png");
}

/**
     * Wysyła wiadomość do klienta poprzez sesję WebSocket.
     * @param wiadomosc do przeslania jako string
     */
    private void sendResponse(Session session, String message) {
        try {
            session.getBasicRemote().sendText(message);
            String additionalMessage = String.valueOf("Liczba poprawnych zgadnięć: " + Count);
            session.getBasicRemote().sendText(additionalMessage);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}