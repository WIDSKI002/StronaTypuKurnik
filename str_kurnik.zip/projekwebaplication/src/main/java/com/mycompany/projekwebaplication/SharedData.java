/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projekwebaplication;

/**
 *
 * @author mlody
 */
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

 /**
     * Wlacza cala gre
     */
public class SharedData implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final String JDBC_URL = "jdbc:derby://localhost:1527/test";
    private static final String USERNAME = "dawid";
    private static final String PASSWORD = "dawid";
    private static final String gra = "kosci";
    private String Gracz1 = "bb" ;
   private String Gracz2 = "bb";

 /**
     * Metoda zwracająca nazwę gracza 1 z dodatkowym tekstem "Przypisany1".
     * @return nazwę gracza 1 z dodatkowym tekstem jako string
     */
    public String getgracz1() {
        
        return "Przypisany1"+Gracz1;
    }

 /**
     * Metoda zwracająca nazwę gracza 2 z dodatkowym tekstem "Przypisany1".
     * @return nazwę gracza 1 z dodatkowym tekstem jako string
     */
 public String getgracz2() {
        
        return "Przypisany2"+Gracz2;
    }

 /**
     * Metoda przyjmująca jako argument nazwę gracza i przypisująca ją do pola Gracz1.
     * @param string do przypisania do pola
     */
    public void Przypisz1(String msg) {
        
  
Gracz1 = msg;
    }

 /**
     * Metoda przyjmująca jako argument nazwę gracza i przypisująca ją do pola Gracz2, pod warunkiem, że Gracz2 wcześniej był ustawiony na "bb".
     * @param string do przypisania do pola
     */
    public void Przypisz2(String msg) {
        
        if(Gracz2 == "bb"){
Gracz2 = msg;}
    }
    
    
 /**
     * Metoda obsługująca zapisywanie wyników graczy w bazie danych. Sprawdza, czy nick gracza istnieje w tabeli wyników. Jeśli tak, zaktualizuje wynik; jeśli nie, dodaje nowy rekord.
     * @param nickk Przyjmuje jako argument numer gracza (nickk).
     */
    public void wygrana(int nickk) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            // Sprawdź, czy nick już istnieje w tabeli
             String nick="ta";
            if(nickk == 1)
               nick=Gracz1;
             if(nickk==2)
                 nick=Gracz1;
            String selectQuery = "SELECT * FROM wynik WHERE nick = ?";
            try (PreparedStatement selectStatement = connection.prepareStatement(selectQuery)) {
                selectStatement.setString(1, nick);
                try (ResultSet resultSet = selectStatement.executeQuery()) {
                    if (resultSet.next()) {
                        // Nick już istnieje, zaktualizuj wynik
                        int currentResult = resultSet.getInt("wynik");
                        int newResult = currentResult + 1;

                        String updateQuery = "UPDATE wynik SET wynik = ? WHERE nick = ?";
                        try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                            updateStatement.setInt(1, newResult);
                            updateStatement.setString(2, nick);
                            updateStatement.executeUpdate();
                        }
                    } else {
                        // Nick nie istnieje, dodaj nowy rekord
                        String insertQuery = "INSERT INTO wynik (jakagra,nick, wynik) VALUES ('kosci',?, 1)";
                        try (PreparedStatement insertStatement = connection.prepareStatement(insertQuery)) {
                            insertStatement.setString(1, nick);
                            insertStatement.executeUpdate();
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
}